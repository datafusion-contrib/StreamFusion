package tech.streamfusion.arrow;

import static org.junit.jupiter.api.Assertions.*;

import java.nio.charset.StandardCharsets;
import java.util.Random;
import org.apache.arrow.memory.RootAllocator;
import org.apache.arrow.vector.VarCharVector;
import org.apache.flink.core.memory.MemorySegment;
import org.apache.flink.core.memory.MemorySegmentFactory;
import org.apache.flink.table.data.binary.BinaryStringData;
import org.apache.flink.table.data.conversion.StringStringConverter;
import org.junit.jupiter.api.Test;

class JdkStringConverterTest {
  private final StringStringConverter stock = new StringStringConverter();
  private final JdkStringConverter candidate = new JdkStringConverter();

  @Test
  void everyTwoByteSequenceMatchesReleasedConversionAndPreservesBytes() {
    for (int i = 0; i < 65536; i++) compare(new byte[] {(byte) (i >> 8), (byte) i});
    var random = new Random(237);
    for (int i = 0; i < 4096; i++) {
      byte[] bytes = new byte[3 + random.nextInt(30)];
      random.nextBytes(bytes);
      compare(bytes);
    }
    for (byte[] bytes :
        new byte[][] {
          {(byte) 0xe0, (byte) 0x80, (byte) 0x80},
          {(byte) 0xed, (byte) 0xa0, (byte) 0x80},
          {(byte) 0xf0, (byte) 0x80, (byte) 0x80, (byte) 0x80},
          {(byte) 0xf4, (byte) 0x90, (byte) 0x80, (byte) 0x80},
          {(byte) 0xe3, (byte) 0x80},
          {(byte) 0xf0, (byte) 0x90, (byte) 0x80}
        }) compare(bytes);
  }

  private void compare(byte[] bytes) {
    byte[] padded = new byte[bytes.length + 6];
    java.util.Arrays.fill(padded, (byte) 0xff);
    System.arraycopy(bytes, 0, padded, 3, bytes.length);
    var expected = BinaryStringData.fromBytes(padded, 3, bytes.length);
    var actual = BinaryStringData.fromBytes(padded, 3, bytes.length);
    assertEquals(stock.toExternal(expected), candidate.toExternal(actual));
    assertSame(actual.getJavaObject(), candidate.toExternal(actual));
    assertArrayEquals(bytes, actual.toBytes());
  }

  @Test
  void validUnicodeLongValuesAndCachedJavaCodeUnitsKeepReleasedBehavior() {
    for (String value :
        new String[] {
          "", "ASCII", "é\u0000\ue000𐀀🙂", "largeé🙂".repeat(4096), "left\ud800right\udfff"
        }) {
      compare(value.getBytes(StandardCharsets.UTF_8));
      var binary = BinaryStringData.fromString(value);
      assertSame(value, candidate.toExternal(binary));
      assertSame(value, stock.toExternal(binary));
    }
    assertNull(candidate.toExternalOrNull(null));
    var left = BinaryStringData.fromBytes("\ue000".getBytes(StandardCharsets.UTF_8));
    var right = BinaryStringData.fromBytes("𐀀".getBytes(StandardCharsets.UTF_8));
    candidate.toExternal(left);
    candidate.toExternal(right);
    var stockLeft = BinaryStringData.fromBytes(left.toBytes());
    var stockRight = BinaryStringData.fromBytes(right.toBytes());
    stock.toExternal(stockLeft);
    stock.toExternal(stockRight);
    assertEquals(stockLeft.compareTo(stockRight), left.compareTo(right));
  }

  @Test
  void multiSegmentAndClosedOffHeapInputsRetainOwnedExternalStrings() {
    var split =
        BinaryStringData.fromAddress(
            new MemorySegment[] {
              MemorySegmentFactory.wrap(new byte[] {0, 0, 'A', 'B'}),
              MemorySegmentFactory.wrap(new byte[] {'C', 'D', 0, 0})
            },
            2,
            4);
    assertEquals("ABCD", candidate.toExternal(split));
    String retained;
    try (var allocator = new RootAllocator();
        var vector = new VarCharVector("v", allocator)) {
      vector.allocateNew();
      vector.setSafe(0, "é🙂".getBytes(StandardCharsets.UTF_8));
      vector.setValueCount(1);
      retained = candidate.toExternal(BorrowedStringValues.create(vector).value(0));
    }
    assertEquals("é🙂", retained);
  }

  @Test
  void onlyTheExactReleasedConverterIsReplaced() {
    var custom = new StringStringConverter() {};
    var original = new StringStringConverter();
    Object marker = new Object();
    Object[] references = {original, custom, null, marker};
    JdkStringConverter.replaceStandardConverters(references);
    assertInstanceOf(JdkStringConverter.class, references[0]);
    assertSame(custom, references[1]);
    assertNull(references[2]);
    assertSame(marker, references[3]);
  }

  @Test
  void converterSurvivesFlinksTaskSerialization() throws Exception {
    var restored =
        org.apache.flink.util.InstantiationUtil.clone(candidate, getClass().getClassLoader());
    var bytes = "retainedé🙂".getBytes(StandardCharsets.UTF_8);
    assertEquals(
        stock.toExternal(BinaryStringData.fromBytes(bytes)),
        restored.toExternal(BinaryStringData.fromBytes(bytes)));
  }
}

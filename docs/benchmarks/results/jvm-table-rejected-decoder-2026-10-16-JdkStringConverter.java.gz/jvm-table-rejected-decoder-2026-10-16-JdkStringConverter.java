package tech.streamfusion.arrow;

import java.nio.charset.StandardCharsets;
import org.apache.flink.annotation.Internal;
import org.apache.flink.table.data.StringData;
import org.apache.flink.table.data.binary.BinaryStringData;
import org.apache.flink.table.data.conversion.StringStringConverter;

/** Preserves Flink's String conversion and cache while using the JDK's heap UTF-8 decoder. */
@Internal
public final class JdkStringConverter extends StringStringConverter {
  private static final long serialVersionUID = 1L;

  @Override
  public String toExternal(StringData internal) {
    if (internal instanceof BinaryStringData) {
      var binary = (BinaryStringData) internal;
      if (binary.getJavaObject() == null) {
        var segments = binary.getSegments();
        if (segments.length == 1 && !segments[0].isOffHeap()) {
          String value =
              new String(
                  segments[0].getArray(),
                  binary.getOffset(),
                  binary.getSizeInBytes(),
                  StandardCharsets.UTF_8);
          binary.setJavaObject(value);
          return value;
        }
      }
    }
    return super.toExternal(internal);
  }

  public static void replaceStandardConverters(Object[] references) {
    for (int i = 0; i < references.length; i++) {
      if (references[i] != null && references[i].getClass() == StringStringConverter.class)
        references[i] = new JdkStringConverter();
    }
  }
}

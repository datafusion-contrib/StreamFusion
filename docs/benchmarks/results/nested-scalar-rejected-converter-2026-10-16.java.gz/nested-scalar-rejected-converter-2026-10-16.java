package tech.streamfusion.planner;

import java.util.List;
import org.apache.flink.table.data.GenericArrayData;
import org.apache.flink.table.data.GenericRowData;
import org.apache.flink.table.data.conversion.DataStructureConverter;
import org.apache.flink.table.data.conversion.DataStructureConverters;
import org.apache.flink.table.types.DataType;
import org.apache.flink.table.types.logical.LogicalTypeRoot;
import org.apache.flink.types.Row;

/** Avoid an intermediate binary-array copy before synchronous Arrow result materialization. */
final class GenericStringArrayConverter implements DataStructureConverter<Object, Object> {
  private final DataStructureConverter<Object, Object> delegate;
  private final DataStructureConverter<Object, Object>[] children;
  private final boolean row;

  private GenericStringArrayConverter(
      DataType type, DataStructureConverter<Object, Object>[] children, boolean row) {
    this.delegate = released(type);
    this.children = children;
    this.row = row;
  }

  @SuppressWarnings("unchecked")
  private static DataStructureConverter<Object, Object> released(DataType type) {
    return (DataStructureConverter<Object, Object>) DataStructureConverters.getConverter(type);
  }

  @SuppressWarnings("unchecked")
  static DataStructureConverter<Object, Object> create(DataType type) {
    List<DataType> fields = type.getChildren();
    var logical = type.getLogicalType().getTypeRoot();
    if (logical == LogicalTypeRoot.ARRAY
        && type.getConversionClass() == String[].class
        && fields.get(0).getLogicalType().isNullable()
        && fields.get(0).getLogicalType().getTypeRoot() == LogicalTypeRoot.VARCHAR
        && fields.get(0).getConversionClass() == String.class)
      return new GenericStringArrayConverter(
          type, new DataStructureConverter[] {released(fields.get(0))}, false);
    if (logical != LogicalTypeRoot.ROW || type.getConversionClass() != Row.class) return null;
    var converters = new DataStructureConverter[fields.size()];
    boolean optimized = false;
    for (int i = 0; i < fields.size(); i++) {
      var converter = create(fields.get(i));
      optimized |= converter != null;
      converters[i] = converter == null ? released(fields.get(i)) : converter;
    }
    return optimized ? new GenericStringArrayConverter(type, converters, true) : null;
  }

  @Override
  public void open(ClassLoader loader) {
    delegate.open(loader);
    for (var child : children) child.open(loader);
  }

  @Override
  public Object toInternal(Object external) {
    if (row) {
      Row source = (Row) external;
      if (source.getFieldNames(false) != null) return delegate.toInternal(source);
      var result = new GenericRowData(source.getKind(), children.length);
      for (int i = 0; i < children.length; i++)
        result.setField(i, children[i].toInternalOrNull(source.getField(i)));
      return result;
    }
    Object[] source = (Object[]) external;
    Object[] result = new Object[source.length];
    for (int i = 0; i < source.length; i++) result[i] = children[0].toInternalOrNull(source[i]);
    return new GenericArrayData(result);
  }

  @Override
  public Object toExternal(Object internal) {
    return delegate.toExternal(internal);
  }
}
